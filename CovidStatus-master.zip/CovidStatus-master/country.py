class Country:
    def __init__(self, country_name, total_cases, new_cases, total_deaths, new_deaths, total_recovered):
        self.country_name = country_name
        self.total_cases =  total_cases
        self.new_cases = new_cases
        self.total_deaths = total_deaths
        self.new_deaths = new_deaths
        self. total_recovered =  total_recovered

