export default [
    {
        US: 100,
        CA: 120,
        UK: 400,
    }
  ]