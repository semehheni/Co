<template>
 <img class="" src="@/assets/images/logo/logoCovid.png" alt="" />
</template>
